import 'package:flutter/material.dart';

class BaseWidget extends StatelessWidget {
  final Widget child;
  const BaseWidget({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var mediaQueryData = MediaQuery.of(context);
    // Buat variable yang menyimpan nilai MediaQuery
    final double deviceWidth = mediaQueryData.size.width;

    // Contoh penggunaan MediaQuery untuk conditional padding
    final double horizontalPadding = deviceWidth > 600 ? 20.0 : 10.0;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
      child: child,
    );
  }
}
