import 'package:flutter/material.dart';

class DrawerScreen extends StatefulWidget {
  const DrawerScreen({super.key});

  @override
  State<DrawerScreen> createState() => _DrawerScreenState();
}

class _DrawerScreenState extends State<DrawerScreen> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color.fromRGBO(229, 229, 203, 11), // Warna background drawer
      child: ListView( // Menggunakan ListView untuk scrollable drawer
        children: [
          const UserAccountsDrawerHeader(
            // currentAccountPicture: CircleAvatar(
            //   backgroundImage: AssetImage('assets/profile.png'), // Pastikan path gambar benar
            // ),
            accountName: Text("XuenSun"),
            accountEmail: Text('Siap Membantu Memahami Diri Anda'),
            decoration: BoxDecoration(color: Color.fromRGBO(26, 18, 11, 11),),
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: const Text('Settings'),
            onTap: () {
              Navigator.pop(context); // Menutup drawer saat item dipilih
              showDialog(
                context: context,
                builder: (context) => const AlertDialog(
                  title: Text("Settings"),
                  content: Text("Settings tapped"),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
