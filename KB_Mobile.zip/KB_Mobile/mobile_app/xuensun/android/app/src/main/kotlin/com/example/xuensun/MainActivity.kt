package com.example.xuensun

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
